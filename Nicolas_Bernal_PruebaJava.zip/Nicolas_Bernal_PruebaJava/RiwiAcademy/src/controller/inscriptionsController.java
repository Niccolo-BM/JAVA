package controller;

public class inscriptionsController {
}
